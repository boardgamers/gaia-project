# @boardgamers/protocol

TypeScript contracts and framework-independent helpers for games on Boardgamers.
The package uses the existing BGS emitter protocol. It does not add a second
`postMessage` bridge or impose a chat layout, framework, or game engine.

```sh
npm install @boardgamers/protocol
```

ES modules and TypeScript declarations are included. Bundle the package into your
viewer with Vite, Rollup, or another browser bundler. Node 24+ and pnpm are used to
develop the package; the browser code has no Node dependencies.

| Import                           | Purpose                                                         |
| -------------------------------- | --------------------------------------------------------------- |
| `@boardgamers/protocol`          | Event types and Zod runtime schemas                             |
| `@boardgamers/protocol/viewer`   | Viewer commands, callbacks, lifecycle, coverage report          |
| `@boardgamers/protocol/chat`     | Chat state, drafts, acknowledgements, unread tracking, mentions |
| `@boardgamers/protocol/chat/dom` | Optional chat panel, input and scrolling bindings               |
| `@boardgamers/protocol/mentions` | Mention parsing and autocomplete without a viewer dependency    |
| `@boardgamers/protocol/linkify`  | Safe text/link/mention segmentation                             |
| `@boardgamers/protocol/testing`  | Local host that records emitted events                          |
| `@boardgamers/protocol/engine`   | Generic engine interface and required-method report             |

## Viewer

A minimal tic-tac-toe integration, with rendering omitted. The
[tutorial](https://docs.boardgamers.space/guide/tictactoe#viewer) has the complete viewer.

```ts
import { registerViewer } from "@boardgamers/protocol/viewer";
import type { GameState, Coord } from "./engine";

registerViewer<GameState, Coord>("tictactoe", ({ target, move }) => {
	// Mount the board in target; cell clicks call move({ x, y }).

	return {
		onState(state) {
			// Render the board and result; enable empty cells only on your turn.
		},
		onPlayer({ index }) {
			// Store this seat (undefined for spectators) and refresh input controls.
		},
	};
});
```

Configure `tictactoe` as the viewer's global name in BGS. If using Vite, set
`build.lib.name` to `tictactoeBundle`. The library handles registration, state refreshes,
readiness, and cleanup. With a framework, await rendering in `onState` and unmount
in `destroy`. See [incremental logs](https://docs.boardgamers.space/guide/viewer-api#incremental-logs)
for an alternative to full-state updates.

Event payloads are validated automatically. Pass `stateSchema` and `moveSchema`
in the third argument for game-specific validation. Use the registration’s `diagnostics()`
method in local tests to check callback coverage. See the [full guide](https://docs.boardgamers.space/guide/protocol-library)
for details.

## Chat

Create a `ChatController` inside the registration callback and return it as `chat`.
Use `mountChat(container, { chat, openPlayer })` from `/chat/dom` for a complete panel,
or keep your own UI with `bindChatComposer` and `bindChatViewport`.

The shared behaviors cover rich text, mentions, drafts, send acknowledgements,
scrolling, visible read receipts and on-demand translation with an original-text toggle. Colors, author portraits, labels and viewport
insets are customizable; your game owns layout, tabs and shortcuts.

From 0.6.1, BGS supplies `readState` (`userId`, `lastReadAt` in Unix milliseconds)
in `chat:state`. The controller restores unread badges after a reload, excluding
your own messages and system events. A `null` read state clears account-specific
tracking on logout. Keep inactive chat panels closed with `chat.setOpen(false)`;
read receipts are sent only for visible messages in an open panel.

When BGS supplies `translationTarget` in `chat:state`, `mountChat` shows translation
controls automatically. The platform owns language detection, permissions, inference
and caching. Rebuild viewers with protocol 0.4.0 or later to enable these controls;
custom renderers can use `chat.toggleTranslation(messageId)` and
`snapshot.translations[messageId]`. `snapshot.messages` always contains originals.

From 0.5.0, the shared panel and composer also support ↑ to edit your last eligible
message, Enter to save and Escape to cancel. The panel adds a pencil for touch users.
BGS controls ownership and the 15-minute editing window; failed saves preserve the draft.
Custom UIs use `chat.canEdit(message)`, `composer.edit(messageId)`,
`snapshot.editingId`, `chat.editLabels` and `chat.cancelEditing()`.

[Examples and customization](https://docs.boardgamers.space/guide/protocol-library#chat-state-and-rendering).
[Controller reference](https://docs.boardgamers.space/guide/viewer-api#chatcontroller-reference).

## Engine

Check the exported implementation from the tic-tac-toe tutorial:

```ts
import { inspectEngine, type Engine } from "@boardgamers/protocol/engine";
import * as game from "./engine";
import type { GameState, Coord } from "./engine";

const engine = game satisfies Engine<GameState, Coord>;
console.log(inspectEngine(engine));
```

`defineEngine<State, Move>(implementation)` is also available. Inspection reports
required and optional functions separately; it does not prove rule correctness,
deterministic replay, or secret-state filtering. BGS calls the engine’s named
exports directly, so no registration helper is needed. Implement optional hooks
only when your game needs them.

## Player settings

`onSettings(settings)` receives the current player's per-game engine settings, or
`null` when unavailable. `viewer.updateSetting(name, value)` requests a change to
one setting. BGS validates and saves it, preserving the other settings, then sends
the canonical values back to both the viewer and sidebar. Keep displaying the
confirmed settings until that update arrives. Use `updatePreference` for visual
preferences instead.

## Development and release

From the Boardgamers repository root:

```sh
pnpm install --frozen-lockfile
pnpm --filter @boardgamers/protocol check
pnpm --filter @boardgamers/protocol test:package
pnpm --dir packages/protocol pack --out /tmp/boardgamers-protocol.tgz
```

Install the tarball into a separate game repository to try it before publishing:

```sh
pnpm add /tmp/boardgamers-protocol.tgz
```

Do not commit that temporary dependency. After the release, install the registry
version and commit the game's regular lockfile:

```sh
pnpm add @boardgamers/protocol@^0.3.0
```

Publish with an npm account authorized for the **@boardgamers** scope:

```sh
npm login
pnpm --dir packages/protocol publish --access public
```

Publish from a clean release branch. pnpm defaults to `main`/`master`; pass
`--publish-branch <branch>` when deliberately publishing from another branch.
Use pnpm to pack/publish: it resolves the monorepo's catalog versions. A release
contains compiled JavaScript and declarations, this README, and the license.
Published versions are immutable; increment the package version for the next
release. `prepare` builds the package on workspace install; if scripts are
disabled, run `pnpm --filter @boardgamers/protocol build` before using BGS.

## Player symbols (0.9.0)

BGS sends optional `preferences.bgs.playerSymbols`, an array of symbol IDs in seat
order. These are already resolved for the current viewer: use them unchanged on
player panels, pieces and ownership references when `preferences.colorBlind` is
enabled. Keep the game's default markers when an assignment is absent. Resource,
terrain and faction symbols are separate and must not be remapped.

Import `PLAYER_SYMBOLS`, `playerSymbolGlyph` or `playerSymbolSvg` from
`@boardgamers/protocol/player-symbols` to render the shared shapes. SVG paths use a
24 × 24 view box. Both rendering helpers validate IDs and never render incoming
markup. `resolvePlayerSymbols(preferences, viewerIndex, defaults)` is intended for
hosts: it prioritizes the viewer's own choice, preserves unclaimed defaults, then
allocates distinct fallbacks. It returns an empty array when nobody has chosen a
symbol. The catalogue supports up to eight distinct player symbols.

Full guide: [Protocol library](https://docs.boardgamers.space/guide/protocol-library).

Chat panels separate messages by local date and report reads when message endings
are visible, including inside an unfocused iframe. Custom UIs can use
`chatDateSeparators(messages)` from `/chat` for the same date dividers.

Local tutorials: `createTutorial` from `/tutorial` handles lessons and saved progress. Add the `tutorial` option to `registerViewer` to include them in your viewer bundle. The optional guide is in `/tutorial/dom`. See [Playable tutorials](https://docs.boardgamers.space/guide/tutorials).

## Viewer integration (0.6.0)

`hoverPlayer(index, anchor)` and `leavePlayer()` show BGS player cards;
`openBoardgame()` opens the host-selected boardgame page. Optional
`onThumbnail(size)` returns the board element for a public game share image.
Enable `viewer.thumbnail` only after implementing it. See the
[protocol guide](https://docs.boardgamers.space/guide/protocol-library) for
coordinates, lifecycle, spectator-state handling and fallbacks.

## Undo against bots (0.10.0)

When a single human plays against bots, BGS lets them take back their last saved move: it
replays the engine back to the position before it, so implement `replay(data, { to })`.
BGS sends `onUndoAvailable(available)` whenever the option changes; show an undo control
while it is `true` and call `undo()` from it. BGS then sends the earlier state through
`onState`. BGS has no undo button of its own: players can only undo where the viewer
offers it.

## Custom player colours

BGS sends `preferences.preferredPlayerColors` separately from the complete legacy
`preferences.bgs.playerColors` palette. It contains actual custom six-digit hex
colours or `null` in seat order. Games with chosen colours should keep their game
colour for null seats, apply custom preferences, and resolve conflicts against
that chosen palette. The viewing player's custom colour takes priority; spectators
use seat order. Keep accessibility palettes authoritative. See the
[viewer API](https://docs.boardgamers.space/guide/viewer-api#preferences).

The optional `EngineContext.preferredPlayerColors` field supplies the same public
preferences at `init`. Engines may skip those seats during colour selection, then
assign unused fallback colours after other players choose. Snapshot the field for
deterministic replays; later profile changes must not change the setup sequence.

## Server-driven games (0.8.0)

`EngineContext` supplies trusted server time and player IDs. `advanceTime` / `nextWakeup` schedule game events without a browser.

- `presenceChanged`: BGS reports visible, connected participant seats. No heartbeat moves needed.
- `phase`: report waiting, playing, or between rounds; explicitly allow leaving without a penalty where appropriate.
- `tableProgress`: export a compact, versioned checkpoint for the next game. `init` receives it in `context.table.progress`; `migrateTableProgress` upgrades older schemas.

Use `InvalidMoveError` for expected move rejections. See the [timing guide](https://docs.boardgamers.space/guide/timing#games-with-their-own-clock) for details.
